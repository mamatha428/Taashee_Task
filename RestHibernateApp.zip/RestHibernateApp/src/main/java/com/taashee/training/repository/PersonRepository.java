package com.taashee.training.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.taashee.training.entity.Person;

public interface PersonRepository extends JpaRepository<Person,Integer>{

}

package com.taashee.training.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class AadharCard {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String aadharNo;
	@OneToOne(mappedBy="aadhar")
	private IndianCitizen citizen;
     public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	@Override
	public String toString() {
		return "AadharCard [id=" + id + ", aadharNo=" + aadharNo + "]";
	}
	
   
     
}

package com.taashee.training.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.taashee.training.entity.Account;
import com.taashee.training.entity.Person;
import com.taashee.training.repository.AccountRepository;
import com.taashee.training.repository.PersonRepository;

@RestController
public class manyToManyController {
	private final PersonRepository personRepository;
	private final AccountRepository accountRepository;

	public manyToManyController(PersonRepository personRepository, AccountRepository accountRepository) {

		this.personRepository = personRepository;
		this.accountRepository = accountRepository;
	}
	
	@PostMapping(value="/person")
	public Person savingBankDetails(@RequestBody Person person) {
		return personRepository.save(person);
	}
	
	@PostMapping(value="/account")
	public Account saveAccounts(@RequestBody Account account) {
		return accountRepository.save(account);
	}
	
	@GetMapping(value="/person/all")
	public List<Person> getAllBanks(){
		return personRepository.findAll();
	}
	
	@GetMapping(value="/account/all")
	public List<Account> getAllAccounts(){
		return accountRepository.findAll();
	}
}

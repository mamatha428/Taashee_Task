package com.taashee.training.ConsoleApp.functional;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class FunctionalInterface {
	public static void main(String args[]) {
     TakesOneGivesOne squareOperation=(num)->Math.multiplyExact(num, num);
     TakesOneGivesOne cubeOperation=(num)->Math.multiplyExact(num, Math.multiplyExact(num, num));
     
     System.out.println(squareOperation.performOperation(8L));
     System.out.println(cubeOperation.performOperation(8L));
     
     
     //consumer functional interface example
     //consumer->takes something and gives nothing
     //here accept is the method that is there in the Consumer-> functional interface, so we used it here
    // Consumer<String> takeStringPrintIt=(value)->System.out.println(value);
     // Consumer<String> takeStringPrintIt=(value)->System.out.println(value+"taashee");-> here it is customization to the string , so in this case method references are not used
     Consumer<String> takeStringPrintIt=System.out::println;//-> this is method reference
     takeStringPrintIt.accept("Taashians");
     
     //supplier 
     //supplier takes nothing but gives something
    // Supplier<Double> takesNothingGivesDouble=()->Math.random();
     Supplier<Double> takesNothingGivesDouble=Math::random;// this is also a method reference
    // Double suppliedDouble=takesNothingGivesDouble.get();
   //  takeStringPrintIt.accept(Double.toString(suppliedDouble));
     takeStringPrintIt.accept(Double.toString(takesNothingGivesDouble.get()));
     
     //predicate
     //predicate-> means takes something and gives boolean whether the test is true or false
     Predicate<String> hasTenChars=(value)->value.length()==10;
     takeStringPrintIt.accept(Boolean.toString(hasTenChars.test("ABCDEFGHIJk")));
     
     //function
     //function-> takes something and gives something
    // Function<String,Integer> getStringLength=(value)->value.length();
     Function<String,Integer> getStringLength=String::length;
     takeStringPrintIt.accept(Integer.toString(getStringLength.apply("mamatha udutha")));
     
     
	}
     
}

interface TakesOneGivesOne{
	Long performOperation(Long number);
}

package com.taashee.training.ConsoleApp.model;

import java.util.Objects;

public class Hobby {
    private Integer id;
    private String name;
    private String addedBy;
    private String type;
    
    public Hobby() {}
    

	public Hobby(Integer id, String name, String addedBy, String type) {
		super();
		this.id = id;
		this.name = name;
		this.addedBy = addedBy;
		this.type = type;
	}
	public Integer getId() {
		return id;
	}
	

	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddedBy() {
		return addedBy;
	}
	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "Hobby [id=" + id + ", name=" + name + ", addedBy=" + addedBy + ", type=" + type + "]";
	}
	

	@Override
	public int hashCode() {
		return Objects.hash(addedBy, id, name, type);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Hobby other = (Hobby) obj;
		return Objects.equals(addedBy, other.addedBy) && Objects.equals(id, other.id)
				&& Objects.equals(name, other.name) && Objects.equals(type, other.type);
	}



    
}

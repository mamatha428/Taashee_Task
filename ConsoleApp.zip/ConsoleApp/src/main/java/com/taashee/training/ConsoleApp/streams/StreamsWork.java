package com.taashee.training.ConsoleApp.streams;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

public class StreamsWork {
     public static void main(String args[]) {
    	 List<Integer> numbers=Arrays.asList(1,2,5,6,8,9,5,7,8,99,3);
    	 List<Integer> uniqueNumbers=printUniqueNumbers(numbers);
    	 System.out.println(uniqueNumbers);
    	 
    	 List<Integer> nums=Arrays.asList(1,2,1,2,3,5);
    	 Map<Integer,Integer> numsCountMap=getNumsCountMap(nums);
    	 //printing the map 
    	 for(Entry<Integer,Integer> entry:numsCountMap.entrySet()) {
    		 System.out.println("key:"+entry.getKey()+" value:"+entry.getValue());
    	 }
    	 
    	 //printing the list of integers that occur an odd number of times
    	 printNumbersOccurOddTimes(numsCountMap);
    	 
    	 List<String> names=Arrays.asList("Alpha","Beta","Gamma","Uno","Dos","Tres");
    	 Map<String,Integer> stringAndLengthMap=getStringAndLength(names);
    	//printing the map 
    	 for(Entry<String, Integer> entry:stringAndLengthMap.entrySet()) {
    		 System.out.println("key:"+entry.getKey()+" value:"+entry.getValue());
    	 }
    	 
     }

	private static Map<String, Integer> getStringAndLength(List<String> names) {
		
		return names.stream().filter(name->name.length()>=4).collect(Collectors.toMap(name->name,name->name.length()));
	}

	private static void printNumbersOccurOddTimes(Map<Integer, Integer> numsCountMap) {
		numsCountMap.entrySet().stream().filter(entry->entry.getValue()%2!=0).forEach(num->System.out.println(num));
			
	}

	private static Map<Integer, Integer> getNumsCountMap(List<Integer> nums) {
		return nums.stream().collect(Collectors.toMap(num->num, num->1,(value1,value2)-> value1+value2));
	}

	private static List<Integer> printUniqueNumbers(List<Integer> numbers) {
	//	numbers.stream().distinct().forEach(num->System.out.println(num)); for printing
		return numbers.stream().distinct().collect(Collectors.toList());
		
	}
}

package com.taashee.training.ConsoleApp.streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.taashee.training.ConsoleApp.model.Hobby;

public class CollectionAndStreams {
      public static void main(String args[]) {
    	  List<String> names=Arrays.asList("mamatha","kumar","nandhini","prasanna","miheera");
    	  List<String> nameStartsWithM=getNameStartsWithM(names);
    	  nameStartsWithM=getNameStartWithMviaStreams(names);
    	  System.out.println(nameStartsWithM);
    	  printNamesHavingAtleastFiveChars(names);
    	  
    	  List<Integer> numbers=Arrays.asList(11,21,3,41,5,61,7,81,9);
    	 // System.out.println(areAllNumbersOdd(numbers));
    	  areAllNumbersOdd(numbers);
    	  
    	  List<Hobby> hobbies=Arrays.asList(
    			  new Hobby(1,"dancing","miheera","O"),
    			  new Hobby(2,"singing","chaithya","I"),
    			  new Hobby(3,"paiting","kumar","I"),
    			  new Hobby(4,"cricket","arjun","O"),
    			  new Hobby(4,"cricket","arjun","O")
    			  );
    	  printAllOutdoorHobbyNames(hobbies);
    	  //finding the unique hobbies
    	  findUniqueHobby(hobbies);
    	  
    	  Map<Hobby,Integer> hobbyCountToMap=getHobbyCountToMap(hobbies);
    	  System.out.println();
    	  printHobbyAndCountItems(hobbyCountToMap);
    	  
    	  System.out.println();
    	  printHobbyWithSingleCount(hobbyCountToMap);
    	  
      }

	private static void printHobbyWithSingleCount(Map<Hobby, Integer> hobbyCountToMap) {
		//hobbyCountToMap.entrySet().stream().filter(entry->entry.getValue()==1).forEach(hobby->System.out.println(hobby));
		hobbyCountToMap.entrySet().stream().filter(entry->entry.getValue()==1).forEach(System.out::println);
		
	}

	private static void printHobbyAndCountItems(Map<Hobby, Integer> hobbyCountToMap) {
		hobbyCountToMap.forEach((key,value)->System.out.println("key:"+key+" value:"+value));
	}

	private static Map<Hobby, Integer> getHobbyCountToMap(List<Hobby> hobbies) {
		//here inside the toMap(key,value to be added (like frequency),values like if duplicate hobby objects are there simply adding their frequencies and summing them up
		//return hobbies.stream().collect(Collectors.toMap(hobby->hobby, hobby->1,(value1,value2)-> value1+value2));
		return hobbies.stream().collect(Collectors.toMap(Function.identity(), hobby->1,Integer::sum));//the above one and this statement , both are same only
		
	}

	private static void findUniqueHobby(List<Hobby> hobbies) {
		
	//	hobbies.stream().distinct().forEach(hobby->System.out.println(hobby)); -> if we run this , even the duplicate hobby objects are also
		//printing , to avoid this hascode and equals methods are implemented in Hobby.java
	//	hobbies.stream().distinct().forEach(hobby->System.out.println(hobby));
		hobbies.stream().distinct().forEach(System.out::println);//now after creating the hashcode and equals methods in Hobby.java , the duplicates are not printed in the console
		
	}

	private static void printAllOutdoorHobbyNames(List<Hobby> hobbies) {
		//hobbies.stream().filter(hobby->hobby.getType().equals("O")).forEach(hobby->System.out.println(hobby.getName()));
		//hobbies.stream().filter(hobby->hobby.getType().equals("O")).map(hobby->hobby.getName()).forEach(name->System.out.println(name));
		hobbies.stream().filter(hobby->hobby.getType().equals("O")).map(Hobby::getName).forEach(System.out::println);
		
	}

	private static void areAllNumbersOdd(List<Integer> numbers) {
	  // return numbers.stream().allMatch(num->num%2!=0);->output:false
	//return numbers.stream().noneMatch(num->num%2==0);
	System.out.println(numbers.stream().allMatch(num->num%2!=0));
		
	}

	private static void printNamesHavingAtleastFiveChars(List<String> names) {
		// names.stream().filter(name->name.length()>=4).forEach(name->System.out.println(name));
		//here in the print statement the arguement and the printing name is same, so we can apply method refernce here
		names.stream().filter(name-> name.length()>=4).forEach(System.out::println);
	}

	private static List<String> getNameStartWithMviaStreams(List<String> names) {
		return names.stream().filter(name-> name.startsWith("m")).collect(Collectors.toList());
	}

	private static List<String> getNameStartsWithM(List<String> names) {
		List<String> nameStartWithM=new ArrayList<>();
		for(String name:names) {
			if(name.startsWith("m")) {
				nameStartWithM.add(name);
			}
		}
		return nameStartWithM;
	}
}

package com.taashee.training.ConsoleApp.service;
import com.taashee.training.ConsoleApp.model.Hobby;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.taashee.training.ConsoleApp.dao.HobbyDAO;

public class HobbyService {
     static HobbyDAO hobbyDAO=new HobbyDAO();
	public void fetchAllHobbies() {
		List<Hobby> hobbies=HobbyDAO.fetchAllHobbies();
		hobbies.forEach(hobby->System.out.println(hobby));
		
	}

	public void searchHobbies(Scanner sc) {
		System.out.println("Enter the hobbies in the following format:");
		System.out.println("Name:added by:type");
		System.out.println("type '_' for items you don't want to search:");
		System.out.println("Enter search statement:");
		String[] searchResults=sc.nextLine().split(":");
		if(searchResults.length!=3) {
			System.out.println("Invalid search phrase.");
			return;
		}
		
		List<Hobby> hobbies=hobbyDAO.searchHobby(searchResults[0], searchResults[1], searchResults[2]);
		hobbies.forEach(hobby-> System.out.println(hobby));
		
	}

	public void addHobby(Scanner sc) {
		System.out.println("adding a hobby.");
		System.out.println("Enter the hobby name:");
		String name=sc.nextLine();
		System.out.println("Who is adding it?");
		String addedBy=sc.nextLine();
		System.out.println("Enter the hobby type:");
		String type=sc.nextLine();
	    hobbyDAO.addHobby(name, addedBy, type);//though addHobby returns an integer, not saving here
	    
		
	}

	public void updateHobby(Scanner sc) {
		System.out.println("updating a hobby.");
		System.out.println("Enter id:");
		String id=sc.nextLine();
		//here checking whether the id is there in table Hobby or not
		int checkingId=HobbyDAO.checkId(id);
		if(checkingId!=0) {
		System.out.println("Enter the hobby name:");
		 String name=sc.nextLine();
		System.out.println("Who is adding it?");
		 String addedBy=sc.nextLine();
		System.out.println("Enter the hobby type:");
		String  type=sc.nextLine();
	    hobbyDAO.updateHobby(name, addedBy, type,id);
		}
	
		
	}

	public void deleteHobby(Scanner sc) {
		System.out.println("deleting a hobby.");
		System.out.println("Enter id:");
		 String id=sc.nextLine();
		
	    hobbyDAO.deleteHobby(id);
	    
		
	}

	public void addBulkHobby(Scanner sc) {
		List<Hobby> batchHobbies=new ArrayList<>();
		System.out.println("Enter the number of hobbies to add:");
		int hobbiesToAdd=Integer.parseInt(sc.nextLine());
		while(hobbiesToAdd>0) {
		System.out.println("Number of hobbies to be added:"+hobbiesToAdd);
		System.out.println("Enter the hobby name:");
		 String name=sc.nextLine();
		System.out.println("Who is adding it?");
		 String addedBy=sc.nextLine();
		System.out.println("Enter the hobby type:");
		 String type=sc.nextLine();
		 Hobby hobby=new Hobby(null,name,addedBy,type);
		 batchHobbies.add(hobby);
		 hobbiesToAdd--;
		}
		int hobbiesAdded=HobbyDAO.addbulkHobbies(batchHobbies);
		if(hobbiesAdded==batchHobbies.size()) {
			System.out.printf("Successfully added %d hobbies\n",hobbiesAdded);
		}
		else {
			System.out.printf("Failed to add %d hobbies:\n",hobbiesAdded);
		}
		
	
		
	}

	public void searchHobbiesAnotherWay(Scanner sc) {
		System.out.println("Enter the hobbies in the following format:");
		System.out.println("Name:added by:type");
		System.out.println("type '_' for items you don't want to search:");
		System.out.println("Enter search statement:");
		String[] searchResults=sc.nextLine().split(":");
		if(searchResults.length!=3) {
			System.out.println("Invalid search phrase.");
			return;
		}
		String name=searchResults[0].equals("_")?null:searchResults[0];
		String addedBy=searchResults[1].equals("_")?null:searchResults[1];
		String type=searchResults[2].equals("_")?null:searchResults[2];
		List<Hobby> hobbies=hobbyDAO.searchHobbies(name, addedBy, type);
		hobbies.forEach(hobby-> System.out.println(hobby));
		
		
	}

	public void printAppIntroAndOptions() {
		System.out.println("Select the task you wish to perform");
		System.out.println("1:Fetch all hobbies.");
		System.out.println("2:Add a new hobby.");
		System.out.println("3:Update a hobby.");
		System.out.println("4:Delete a hobby.");
		System.out.println("5.Search a hobby.");
		System.out.println("6.Add Bulk hobbies.");
		System.out.println("7.Search in another way.");
		System.out.println("0:Exit.");
		
	}

}

package com.taashee.training.ConsoleApp;
import com.taashee.training.ConsoleApp.dao.HobbyDAO;
import com.taashee.training.ConsoleApp.model.ConsoleAction;
import com.taashee.training.ConsoleApp.service.HobbyService;

import java.util.Scanner;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
       // System.out.println("Hello World!");
    	launchJDBCConsole();
    }
     static HobbyDAO hobbyDAO=new HobbyDAO();
     private static HobbyService hobbyService=new HobbyService();
	
	private static void launchJDBCConsole() {
		
		System.out.println("Welcome to the JDBC Console App");
		String input="-1";
		while(input!="0") {
			hobbyService.printAppIntroAndOptions();
			Scanner sc=new Scanner(System.in);
			input=sc.nextLine();
			ConsoleAction consoleAction=ConsoleAction.from(input);
			//List<Hobby> hobbies;//created because posing error
			switch(consoleAction) {
			case FETCH_HOBBY:
				//System.out.println("fetching all hobbies");
				//hobbyDAO.fetchAllHobbies();
				//hobbyDAO.fetchHobbies();
				//List<com.taashee.training.ConsoleApp.model.Hobby> hobbies=HobbyDAO.fetchAllHobbies();
				//hobbies.forEach(hobby->System.out.println(hobby));
				hobbyService.fetchAllHobbies();
				break;
			case ADD_HOBBY:
				hobbyService.addHobby(sc);
				break;
			case UPDATE_HOBBY:
				hobbyService.updateHobby(sc);
				break;
			case DELETE_HOBBY:
				hobbyService.deleteHobby(sc);
				break;
			case SEARCH_HOBBY:
				/*System.out.println("searching a hobby.");
				System.out.println("Enter the hobby name:");
				 name=sc.nextLine();
				System.out.println("Who is adding it?");
				 addedBy=sc.nextLine();
				System.out.println("Enter the hobby type:");
				 type=sc.nextLine();
				  hobbies=hobbyDAO.searchHobby(name,addedBy,type);
					hobbies.forEach(hobby->System.out.println(hobby));
					*/
			    hobbyService.searchHobbies(sc);
				break;
			case ADD_BULK_HOBBY:
				hobbyService.addBulkHobby(sc);
				break;
				//here i have added another search case, for my understanding
			case SEARCH_HOBBY_ANOTHER:
			    hobbyService.searchHobbiesAnotherWay(sc);
			    break;
			case EXIT:
			    System.out.println("Exited");
			   // sc.close(); posing the error, if i close the sc
			    return;
			default:
			    System.out.println("Enter valid string");
		
		
			}
			
         //  sc.close();
		}
		
	}
   
}

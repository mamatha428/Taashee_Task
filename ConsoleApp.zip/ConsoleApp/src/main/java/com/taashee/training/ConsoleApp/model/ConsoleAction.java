package com.taashee.training.ConsoleApp.model;

public enum ConsoleAction {
     FETCH_HOBBY("1"), ADD_HOBBY("2"), UPDATE_HOBBY("3"), DELETE_HOBBY("4"), SEARCH_HOBBY("5"), ADD_BULK_HOBBY("6"),SEARCH_HOBBY_ANOTHER("7"), EXIT("0"), INVALID("-1");
	 private String consoleActionNumber;
	 ConsoleAction(String consoleActionNumber){
		 this.consoleActionNumber=consoleActionNumber;
	 }
	 
	 //getter for consoleActionnumber
	 public String getConsoleActionNumber() {
		 return consoleActionNumber;
	 }

	 public static ConsoleAction from(String input) {
		for(ConsoleAction action:ConsoleAction.values()) {
			if(action.consoleActionNumber.equals(input)) {
				return action;
			}
		}
		return ConsoleAction.INVALID;
	}
}

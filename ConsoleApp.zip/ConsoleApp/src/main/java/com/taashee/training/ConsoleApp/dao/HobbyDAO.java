package com.taashee.training.ConsoleApp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

import com.taashee.training.ConsoleApp.ConnectionFactory;
import com.taashee.training.ConsoleApp.model.Hobby;

public class HobbyDAO {
	//FOR GOOD READANILITY AND MODIFICATIONS THIS PRACTICE IS GOOD ONE
    private static final String ADD_HOBBY_QUERY="Insert into Hobby(name,added_by,type) values(?,?,?)";
	private static final String ADD_ALL_HOBBIES_QUERY = "SELECT * FROM HOBBY";
	private static final String UPDATE_HOBBY_QUERY = "UPDATE HOBBY SET NAME=?, ADDED_BY=?, TYPE=? WHERE ID=?";
	private static final String DELETE_HOBBY_QUERY = "DELETE FROM HOBBY WHERE ID=?";
	private static final String CHECK_HOBBY_QUERY = "SELECT COUNT(*) FROM HOBBY WHERE ID=?";
	private static final String SEARCH_HOBBY_QUERY = "SELECT * FROM HOBBY WHERE name LIKE ? AND added_by LIKE ? AND type = ?"; 
   
    public int addHobby(String name,String addedBy,String type) {
    	int rowsAffected=0;
    	try( Connection con=ConnectionFactory.getConnection();PreparedStatement ps=con.prepareStatement(ADD_HOBBY_QUERY)) {
			ps.setString(1, name);
			ps.setString(2, addedBy);
			ps.setString(3, type);
			rowsAffected=ps.executeUpdate();
			if(rowsAffected==1) {
				System.out.println("Hobby added successfully "+name);
			}
			else {
				System.out.println("failed to add hobby "+name);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	return rowsAffected;
    }
    /*
     * method i tried
    //method for fetching all the hobbies
    public void fetchHobbies() {
    	try {
			PreparedStatement ps=con.prepareStatement("Select *from Hobby");
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				int id=rs.getInt("id");
				String name=rs.getString("name");
				String added_by=rs.getString("added_by");
				String type=rs.getString("type");
				
				System.out.println("Id: "+id+" name:"+name+" added by:"+added_by+" type is:"+type);
			}
		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
*/
	public static List<Hobby> fetchAllHobbies() {
		List<Hobby> hobbies=new ArrayList<>();
       
        
		try( Connection con=ConnectionFactory.getConnection();	Statement st = con.createStatement()) {
		
			 ResultSet rs=st.executeQuery(ADD_ALL_HOBBIES_QUERY);
		        while(rs.next()) {
		        	int id=rs.getInt("id");
		        	String name=rs.getString("name");
		        	String addedBy=rs.getString("added_by");
		        	String type=rs.getString("type");
		        	Hobby hobby=new Hobby(id,name,addedBy,type);
		        	hobbies.add(hobby);
		        }
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
       
        return hobbies;
        
	}
	//updating a hobby
	public int updateHobby(String name, String addedBy, String type, String id) {
		int rowsUpdated=0;
		
    	try( Connection con=ConnectionFactory.getConnection();PreparedStatement ps=con.prepareStatement(UPDATE_HOBBY_QUERY)) {
			ps.setString(1, name);
			ps.setString(2, addedBy);
			ps.setString(3, type);
			ps.setInt(4, Integer.parseInt(id));
			rowsUpdated=ps.executeUpdate();
			if(rowsUpdated==1) {
				System.out.println("Hobby updated successfully of Id "+id);
			}
			else {
				System.out.println("failed to update hobby of Id "+id);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
    	return rowsUpdated;
		
	}
	//deleting a hobby
	public int deleteHobby(String id) {
		int rowsDeleted=0;
    	try( Connection con=ConnectionFactory.getConnection()) {
    		try(PreparedStatement psCheck=con.prepareStatement(CHECK_HOBBY_QUERY)){
    			psCheck.setInt(1, Integer.parseInt(id));
    			ResultSet rs=psCheck.executeQuery();
    			if(rs.next()) {
    				int count=rs.getInt(1);//gives the number of records of that id , if there in the table hobby or not
    				if(count==0) {
    					System.out.println("Id not found in the table->"+id);
    					return rowsDeleted;
    				}
    			}
    		} catch (SQLException e) {
    			
    			e.printStackTrace();
    		}
    		//this is when the id  is there in the table
			try(PreparedStatement ps=con.prepareStatement(DELETE_HOBBY_QUERY)){
			ps.setInt(1, Integer.parseInt(id));
			rowsDeleted=ps.executeUpdate();
			if(rowsDeleted==1) {
				System.out.println("Hobby deleted successfully of Id "+id);
			}
			else {
				System.out.println("failed to delete hobby of Id "+id);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
    
		
	}
    	 catch (SQLException e) {
 		
 			e.printStackTrace();
 		}
    	return rowsDeleted;
}
	//for updating the hobby, here this method will return if the id is there in the hobby table or not
	public static int checkId(String id) {
		int checkCount=0;
		try( Connection con=ConnectionFactory.getConnection()) {
    		try(PreparedStatement psCheck=con.prepareStatement(CHECK_HOBBY_QUERY)){
    			psCheck.setInt(1, Integer.parseInt(id));
    			ResultSet rs=psCheck.executeQuery();
    			if(rs.next()) {
    				checkCount=rs.getInt(1);//gives the number of records of that id , if there in the table hobby or not
    				if(checkCount==0) {
    					System.out.println("Id not found in the table->"+id);
    					return checkCount;
    				}
    			}
    		} catch (SQLException e) {
    			
    			e.printStackTrace();
    		}
	
	} catch (SQLException e1) {
	
		e1.printStackTrace();
	}
		return checkCount;
	}
	
	//searching a hobby
	public List<Hobby> searchHobby(String name, String addedBy, String type) {
		/*
		 * initial searchHobby implementation code
		 * List<Hobby> hobbies=new ArrayList<>();
    	try( Connection con=ConnectionFactory.getConnection();PreparedStatement ps=con.prepareStatement(SEARCH_HOBBY_QUERY)) {
			ps.setString(1, "%"+name+"%");
			ps.setString(2, "%"+addedBy+"%");
			ps.setString(3, type);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				Integer id=rs.getInt("id");
				Hobby hobby=new Hobby(id,rs.getString("name"),rs.getString("added_by"),rs.getString("type"));
				hobbies.add(hobby);
			}
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		return hobbies;
		*/
		
		List<Hobby> hobbies=new ArrayList<>();
		StringBuilder SEARCH_HOBBY_QUERY=new StringBuilder("Select *from Hobby where name like ? and added_by like ? and type like ?");
		try( Connection con=ConnectionFactory.getConnection();PreparedStatement ps=con.prepareStatement(SEARCH_HOBBY_QUERY.toString())) {
			int index=1;
			if(Boolean.FALSE.equals(Objects.isNull(name)))
		     	ps.setString(index++, "%"+name+"%");
			if(Boolean.FALSE.equals(Objects.isNull(addedBy)))
		     	ps.setString(index++, "%"+addedBy+"%");
			if(Boolean.FALSE.equals(Objects.isNull(type)))
		     	ps.setString(index++,"%"+type+"%");
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				Integer id=rs.getInt("id");
				Hobby hobby=new Hobby(id,rs.getString("name"),rs.getString("added_by"),rs.getString("type"));
				hobbies.add(hobby);
			}
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		return hobbies;
		
		
	}
	
	//adding hobbies in batch
	public static int addbulkHobbies(List<Hobby> batchHobbies) {
		int rowsAdded=0;
		try( Connection con=ConnectionFactory.getConnection();PreparedStatement ps=con.prepareStatement(ADD_HOBBY_QUERY)) {
		  for(Hobby hobby:batchHobbies) {
			ps.setString(1, hobby.getName());
			ps.setString(2, hobby.getAddedBy());
			ps.setString(3, hobby.getType());
		    ps.addBatch();
		  }
		  int[] results=ps.executeBatch();
		  rowsAdded=results.length;
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
    	return rowsAdded;
	}
	//search hobbies code implementation according to sir's logic
	public List<Hobby> searchHobbies(String name, String addedBy, String type) {
		List<Hobby> hobbies=new ArrayList<>();
		Boolean areAllParamsNull=Stream.of(name,addedBy,type).allMatch(Objects::isNull);
		 StringBuilder SEARCH_HOBBY_QUERY=new StringBuilder("Select *from Hobby");
		//if name,type,addedBy any of them not null
		if(Boolean.FALSE.equals(areAllParamsNull)) {
			SEARCH_HOBBY_QUERY.append(" where ")
			.append(Objects.isNull(name)? "" : " name like ?")
			.append(Objects.isNull(addedBy)? "" : " addedBy like ?")
			.append(Objects.isNull(type)? "" : " type = ?");
		}
		try( Connection con=ConnectionFactory.getConnection();PreparedStatement ps=con.prepareStatement(SEARCH_HOBBY_QUERY.toString())) {
			int index=1;
			if(Boolean.FALSE.equals(Objects.isNull(name)))
		     	ps.setString(index++, "%"+name+"%");
			if(Boolean.FALSE.equals(Objects.isNull(addedBy)))
		     	ps.setString(index++, "%"+addedBy+"%");
			if(Boolean.FALSE.equals(Objects.isNull(type)))
		     	ps.setString(index++,type);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				Integer id=rs.getInt("id");
				Hobby hobby=new Hobby(id,rs.getString("name"),rs.getString("added_by"),rs.getString("type"));
				hobbies.add(hobby);
			}
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		return hobbies;
		
	}
}

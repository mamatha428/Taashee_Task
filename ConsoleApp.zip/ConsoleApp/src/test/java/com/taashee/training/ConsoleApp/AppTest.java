package com.taashee.training.ConsoleApp;

import static org.junit.jupiter.api.Assertions.assertEquals;


import org.junit.jupiter.api.Test;

/**
 * Unit test for simple App.
 */
public class AppTest {

    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue() {
        assertEquals(sum(6,4),10);
    }
    Integer sum(int a,int b) {
    	return a+b;
    }
}

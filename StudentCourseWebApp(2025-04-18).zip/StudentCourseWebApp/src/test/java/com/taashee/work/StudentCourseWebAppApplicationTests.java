package com.taashee.work;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentCourseWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.taashee.work.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableWebSecurity
public class ApplicationSecurityConfig extends WebSecurityConfigurerAdapter {
	
	private PasswordEncoder passwordEncoder;
	private UserDetailsService userDetailsService;
	private CustomSuccessHandler customSuccessHandler;
	
	@Autowired
	public ApplicationSecurityConfig(PasswordEncoder passwordEncoder,
			UserDetailsService userDetailsService,CustomSuccessHandler customSuccessHandler) {
		this.passwordEncoder = passwordEncoder;
		String encodedPassword = this.passwordEncoder.encode("password");
		System.out.println("password:" + encodedPassword);
		this.userDetailsService = userDetailsService;
		this.customSuccessHandler=customSuccessHandler;
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		 http.csrf().disable()
         .authorizeRequests()
         .antMatchers("/", "index").permitAll()
         .antMatchers("/admin/**").hasRole("ADMIN")
         .antMatchers("/student/**").hasRole("STUDENT")
		 .antMatchers("/instructor/**").hasRole("INSTRUCTOR")
         .anyRequest().authenticated()
         .and()
         .formLogin()
		 .successHandler(customSuccessHandler);
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) {
		auth.authenticationProvider(daoAuthenticationProvider());
	}

	@Bean
	public DaoAuthenticationProvider daoAuthenticationProvider() {
		DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
		provider.setUserDetailsService(userDetailsService);
		provider.setPasswordEncoder(passwordEncoder);
		return provider;
	}
}

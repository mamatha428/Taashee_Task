package com.taashee.work.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.taashee.work.entity.Student;
import com.taashee.work.service.StudentCourseService;

@Controller
@RequestMapping("/student")
public class StudentController {
private final StudentCourseService studentCourseService;
	
	@Autowired
	public StudentController(StudentCourseService studentCourseService) {
		this.studentCourseService = studentCourseService;
	}
	/*
    @GetMapping("/dashboard")
    public String showStudentDashboard(ModelMap modelMap) {
    	List<Student> students=studentCourseService.getAllStudentsWithCoursesAndInstructors();
    	modelMap.put("students", students);
    	return "student-dashboard";
    }
    */
	@GetMapping("/dashboard")
	public String showStudentDashboard(ModelMap modelMap) {
	    String username = SecurityContextHolder.getContext().getAuthentication().getName();
	    Student student = studentCourseService.getStudentByUsername(username);
	    modelMap.put("student", student);
	    return "student-dashboard";
	}

   
}

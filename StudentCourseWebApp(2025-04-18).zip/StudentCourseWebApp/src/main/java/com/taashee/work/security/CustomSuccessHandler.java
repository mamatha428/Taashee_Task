package com.taashee.work.security;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.stereotype.Service;

@Service
public class CustomSuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler {

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request,HttpServletResponse response,Authentication authentication) throws IOException{
       Collection<? extends GrantedAuthority> authorities=authentication.getAuthorities() ;
       String url=request.getContextPath();
       for(GrantedAuthority authority:authorities) {
    	   if(authority.getAuthority().equalsIgnoreCase("ROLE_ADMIN")) {
    		   url="/admin/dashboard";
    		   break;
    	   }
    	   else if(authority.getAuthority().equalsIgnoreCase("ROLE_STUDENT")) {
    		   url="/student/dashboard";
    		   break;
    	   }
    	   else {
    		   url="/instructor/dashboard";
    		   break;
    	   }
       }
       response.sendRedirect(url);
    }
}

package com.taashee.work.controller;

import java.time.LocalDateTime;
import java.util.Objects;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

//@Controller
public class CustomErrorHandler implements ErrorController {
     @RequestMapping("/error")
     private String handleError(HttpServletRequest request,ModelMap modelMap) {
    	 Object status=request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
    	 if(Objects.nonNull(status)) {
    		 Integer statusCode=Integer.valueOf(status.toString());
    		 if(statusCode==HttpStatus.NOT_FOUND.value()) {
    			 System.out.println("NOT FOUND");
    		 }
    		 else {
    			 modelMap.put("timestamp", LocalDateTime.now());
    			 modelMap.put("message", "IT'S AN ERROR");
    			 System.out.println("strange error");
    		 }
    	 }
    	 return "error";
     }
}

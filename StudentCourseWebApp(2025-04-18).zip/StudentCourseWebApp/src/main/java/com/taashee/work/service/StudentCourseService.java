package com.taashee.work.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.taashee.work.entity.Course;
import com.taashee.work.entity.Instructor;
import com.taashee.work.entity.Student;
import com.taashee.work.repository.CourseRepository;
import com.taashee.work.repository.InstructorRepository;
import com.taashee.work.repository.StudentRepository;

@Service
public class StudentCourseService {

	private final StudentRepository studentRepository;
	private final CourseRepository courseRepository;
	private final InstructorRepository instructorRepository;

	@Autowired
	public StudentCourseService(StudentRepository studentRepository, CourseRepository courseRepository,
			InstructorRepository instructorRepository) {
		this.studentRepository = studentRepository;
		this.courseRepository = courseRepository;
		this.instructorRepository = instructorRepository;
	}

	public List<Student> getAllStudents() {
		return studentRepository.findAll();
	}

	public List<Course> getAllCourses() {
		return courseRepository.findAll();
	}

	public List<Instructor> getAllInstructors() {
		return instructorRepository.findAll();
	}

	public void addInstructor(Instructor instructor) {
		instructorRepository.save(instructor);
		
	}

	public void addCourse(Course course) {
		courseRepository.save(course);
		
	}

	public void assignCourseToInstructor(int courseId, int instructorId) {
		Course course = courseRepository.findById(courseId).orElseThrow(() -> new RuntimeException("Course not found"));
	    Instructor instructor = instructorRepository.findById(instructorId).orElseThrow(() -> new RuntimeException("Instructor not found"));
	    course.setInstructor(instructor);
	    courseRepository.save(course);
	}

	public void assignCourseToStudent(int courseId, int studentId) {
		 Course course = courseRepository.findById(courseId)
			        .orElseThrow(() -> new RuntimeException("Course not found"));
			    
			    Student student = studentRepository.findById(studentId)
			        .orElseThrow(() -> new RuntimeException("Student not found"));
			    
			    Set<Student> students = course.getStudents();
			    
			    if (students == null) {
			        students = new HashSet<>();  
			    }

			    students.add(student);
			    course.setStudents(students);
			    
			    courseRepository.save(course);
		
	}

	public List<Student> getAllStudentsWithCoursesAndInstructors() {
		return studentRepository.getAllStudentsWithCoursesAndInstructors();
	}

	public Student getStudentByUsername(String username) {
		return studentRepository.findByUsernameWithCoursesAndInstructors(username);
	}
	
	

}

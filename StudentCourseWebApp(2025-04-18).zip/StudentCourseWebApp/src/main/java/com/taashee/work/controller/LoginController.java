package com.taashee.work.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {

	@GetMapping(value = "/logout")
	public String showingLogout(HttpSession session) {
		if (session != null)
			session.invalidate();
		return "redirect:/login";
	}
}

package com.taashee.work.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.taashee.work.entity.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student,Integer> {
	
	@Query("SELECT DISTINCT s FROM Student s LEFT JOIN FETCH s.courses c LEFT JOIN FETCH c.instructor")
	List<Student> getAllStudentsWithCoursesAndInstructors();
	
	@Query("SELECT s FROM Student s JOIN FETCH s.courses c JOIN FETCH c.instructor WHERE s.user.username = :username")
	Student findByUsernameWithCoursesAndInstructors(@Param("username") String username);



}


package com.taashee.alfreso_backend.service;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.taashee.alfreso_backend.model.AlfrescoDocument;

import reactor.core.publisher.Mono;

@Service
public class AlfrescoService {

	  private final WebClient webClient;

	    public AlfrescoService(WebClient webClient) {
	        this.webClient = webClient;
	    }

    public List<AlfrescoDocument> getAllDocuments(String ticket, String username) {
        String homeFolderId = getUserHomeFolderId(username, ticket);
        if (homeFolderId == null || homeFolderId.isEmpty()) {
            return Collections.emptyList();
        }

        String url = "/nodes/" + homeFolderId + "/children?alf_ticket=" + ticket;

        String response = webClient.get()
            .uri("http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1" + url)
            .retrieve()
            .bodyToMono(String.class)
            .block();

        System.out.println("Requesting children of home folder: " + url);
        System.out.println("Response: " + response);


        try {
            com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
            var jsonNode = mapper.readTree(response);

            if (jsonNode == null) {
                System.out.println("jsonNode is null");
                return java.util.Collections.emptyList();
            }

            var listNode = jsonNode.get("list");
            if (listNode == null) {
                System.out.println("'list' node is missing in response");
                return java.util.Collections.emptyList();
            }

            var entries = listNode.get("entries");
            if (entries == null) {
                System.out.println("'entries' node is missing in response");
                return java.util.Collections.emptyList();
            }

            return java.util.stream.StreamSupport.stream(entries.spliterator(), false)
                    .map(node -> node.get("entry"))
                  //  .filter(entry -> entry != null && "cm:content".equals(entry.get("nodeType").asText(""))) // filter documents only
                    .map(entry -> {
                        AlfrescoDocument doc = new AlfrescoDocument();
                        doc.setId(entry.get("id").asText(""));
                        doc.setName(entry.get("name").asText(""));
                        doc.setNodeType(entry.get("nodeType").asText(""));
                        // 'content' node may be null, check before accessing 'mimeType'
                        var contentNode = entry.get("content");
                        doc.setMimeType(contentNode != null ? contentNode.get("mimeType").asText("") : "");
                        return doc;
                    })
                    .collect(Collectors.toList());

        } catch (Exception e) {
            e.printStackTrace();
            return java.util.Collections.emptyList();
        }
    }
    
    public String getUserHomeFolderId(String username, String ticket) {
        String url = "http://localhost:8080/alfresco/service/api/people/" + username + "?alf_ticket=" + ticket;

        String response = webClient.get()
            .uri(url)
            .retrieve()
            .bodyToMono(String.class)
            .block();

        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode json = mapper.readTree(response);
            String homeFolderId = "ac1dbf44-90a8-42b1-86a4-20a81f820e0c";
            //json.path("homeFolderId").asText(); // assign to variable
            System.out.println("HomeFolderId for user " + username + ": " + homeFolderId); // now log it
            return homeFolderId;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        
    }

    public String getUserFolderId(String username, String ticket) {
    	 if ("admin".equalsIgnoreCase(username)) {
    	        // Return -root- node id directly
    	        return "-root-";
    	    }
        // This is the root folder under which all user folders exist
        String parentFolderId = "ac1dbf44-90a8-42b1-86a4-20a81f820e0c";
        String url = "http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
                    + parentFolderId + "/children?alf_ticket=" + ticket;

        String response = webClient.get()
            .uri(url)
            .retrieve()
            .bodyToMono(String.class)
            .block();

        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode root = mapper.readTree(response);
            JsonNode entries = root.path("list").path("entries");

            for (JsonNode entryNode : entries) {
                JsonNode entry = entryNode.path("entry");
                String folderName = entry.path("name").asText();
                String nodeId = entry.path("id").asText();

                if (folderName.equals(username)) {
                    System.out.println("Found home folder for " + username + ": " + nodeId);
                    return nodeId;
                }
            }

            System.err.println("User folder not found for " + username);
            return null;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public String getUserDocumentsJson(String userFolderId, String ticket) {
        String childrenUrl = "http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
                + userFolderId + "/children?alf_ticket=" + ticket;

        return webClient.get()
                .uri(childrenUrl)
                .retrieve()
                .bodyToMono(String.class)
                .block();
    }

	public String getAllUsers(String ticket) {
		String url="http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/people?alf_ticket="+ticket;
		return webClient.get()
				.uri(url)
				.retrieve()
				.bodyToMono(String.class)
				.block();
	}

	public String uploadFileToAlfresco(MultipartFile file, String parentFolderId, String ticket) throws IOException {
		byte[] fileBytes = file.getBytes();
	    String fileName = file.getOriginalFilename();

	    MultipartBodyBuilder builder = new MultipartBodyBuilder();
	    builder.part("filedata", new ByteArrayResource(fileBytes) {
	        @Override
	        public String getFilename() {
	            return fileName;
	        }
	    }).header("Content-Type", file.getContentType());

	    builder.part("name", fileName);
	    builder.part("nodeType", "cm:content");
	    builder.part("relativePath", "/"); // optional
	    builder.part("overwrite", "true"); // optional
	    builder.part("majorVersion", "false");

	    String uploadUrl = "http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
	            + parentFolderId + "/children?alf_ticket=" + ticket;

	    return webClient.post()
	            .uri(uploadUrl)
	            .contentType(MediaType.MULTIPART_FORM_DATA)
	            .bodyValue(builder.build())
	            .retrieve()
	            .bodyToMono(String.class)
	            .block();
	}
	public String getFoldersUnderRoot(String ticket) {
	    String url = "http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/nodes/-root-/children?alf_ticket=" + ticket;
	    return webClient.get()
	            .uri(url)
	            .retrieve()
	            .bodyToMono(String.class)
	            .block();
	}

	public ResponseEntity<Resource> downloadfilefromAlfresco(String nodeId, String ticket) {
	    try {
	        // Construct Alfresco URLs with ticket
	        String metadataUrl = String.format(
	            "http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/nodes/%s?alf_ticket=%s", nodeId, ticket);
	        String contentUrl = String.format(
	            "http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/nodes/%s/content?alf_ticket=%s", nodeId, ticket);

	        // Metadata request
	        String metadataResponse = webClient.get()
	            .uri(metadataUrl)
	            .retrieve()
	            .bodyToMono(String.class)
	            .block();

	        ObjectMapper mapper = new ObjectMapper();
	        JsonNode metadataJson = mapper.readTree(metadataResponse);
	        String fileName = metadataJson.path("entry").path("name").asText();
	        String mimeType = metadataJson.path("entry").path("content").path("mimeType").asText();

	        // File content request
	        byte[] fileBytes = webClient.get()
	            .uri(contentUrl)
	            .retrieve()
	            .bodyToMono(byte[].class)
	            .block();

	        ByteArrayResource resource = new ByteArrayResource(fileBytes);

	        return ResponseEntity.ok()
	            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=\"" + fileName + "\"")
	            .contentType(MediaType.parseMediaType(mimeType))
	            .body(resource);

	    } catch (Exception e) {
	        e.printStackTrace();
	        return ResponseEntity.status(500).body(null);
	    }
	}

	public String createGroupInAlfresco(String groupId, String displayName, String ticket) {
	    String url = "http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/groups?alf_ticket=" + ticket;

	    String jsonPayLoad = String.format("{\"id\":\"%s\", \"displayName\":\"%s\"}", groupId, displayName);

	    return webClient.post()
	            .uri(url)
	            .contentType(MediaType.APPLICATION_JSON)
	            .bodyValue(jsonPayLoad)
	            .retrieve()
	            .bodyToMono(String.class)
	            .block();
	}

	public ResponseEntity<?> getAllGroups(String ticket) {
		String url="http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/groups?alf_ticket="+ticket;
		ResponseEntity<String> response=webClient.get().uri(url)
				.retrieve().
				toEntity(String.class)
				.block();
		return ResponseEntity.status(response.getStatusCode()).body(response.getBody());
	}

	public String addUsertoGroup(String groupId, String username, String ticket) {
	    String url = String.format(
	        "http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/groups/%s/members?alf_ticket=%s",
	        groupId, ticket
	    );

	    String payload = String.format("{\"id\":\"%s\", \"memberType\":\"PERSON\"}", username); //  Add memberType

	    System.out.println("POST URL: " + url);
	    System.out.println("Payload: " + payload);

	    return webClient.post()
	            .uri(url)
	            .contentType(MediaType.APPLICATION_JSON)
	            .bodyValue(payload)
	            .retrieve()
	            .bodyToMono(String.class)
	            .block();
	}

	public String createUser(Map<String, String> user, String ticket) {
		String url="http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/people?alf_ticket="+ticket;
		Map<String,Object> requestBody=new HashMap<>();
		requestBody.put("id",user.get("id"));
		requestBody.put("firstName",user.get("firstName"));
		requestBody.put("lastName",user.get("lastName"));
		requestBody.put("email",user.get("email"));
		requestBody.put("password",user.get("password"));
		return webClient.post()
				.uri(url)
				.header(HttpHeaders.CONTENT_TYPE,MediaType.APPLICATION_JSON_VALUE)
				.bodyValue(requestBody)
				.retrieve()
				.bodyToMono(String.class)
				.block();

	}

	
	public String updateUser(Map<String, String> updateData, String ticket, String userId) {
		String url = "http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/people/" + userId + "?alf_ticket=" + ticket;

	    Map<String, Object> requestBody = new HashMap<>();
	    if (updateData.containsKey("firstName")) {
	        requestBody.put("firstName", updateData.get("firstName"));
	    }
	    if (updateData.containsKey("lastName")) {
	        requestBody.put("lastName", updateData.get("lastName"));
	    }
	    if (updateData.containsKey("email")) {
	        requestBody.put("email", updateData.get("email")); // ✅ Add this line
	    }
	    return webClient.put()
	            .uri(url)
	            .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
	            .bodyValue(requestBody)
	            .retrieve()
	            .bodyToMono(String.class)
	            .block();
	}
	
	
	public void disableUser(String userId, String ticket) {
	    String url = "http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/people/" + userId + "?alf_ticket=" + ticket;

	    Map<String, Object> requestBody = new HashMap<>();
	    requestBody.put("enabled", false); // Disabling the user

	    webClient.put()
	            .uri(url)
	            .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
	            .bodyValue(requestBody)
	            .retrieve()
	            .toBodilessEntity()
	            .block();
	}

	public ResponseEntity<?> getAllSites(String ticket) {
	  String url="http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/sites/?alf_ticket="+ticket;
	  String response=webClient.get().uri(url)
			  .retrieve()
			  .bodyToMono(String.class)
			  .block();
	  try {
		  ObjectMapper mapper=new ObjectMapper();
		  JsonNode jsonNode=mapper.readTree(response);
		  return ResponseEntity.ok(jsonNode);
	  }
	  catch(Exception e) {
		  return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("unable to get the sites");
	  }
	}

	public ResponseEntity<?> createSite(String ticket, Map<String, String> siteData) {
		String url="http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/sites?alf_ticket="+ticket;
		if (!siteData.containsKey("id") || !siteData.containsKey("title") || !siteData.containsKey("visibility")) {
		    return ResponseEntity.badRequest().body("Missing site fields");
		}
		String response=webClient.post()
				.uri(url)
				.bodyValue(siteData)
				.retrieve()
				.bodyToMono(String.class)
				.block();
		return ResponseEntity.ok(response);
	}

	public ResponseEntity<?> getSiteDocumentLibrary(String siteId, String ticket) {
	    try {
	        String url = "http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/sites/" + siteId + "/containers?alf_ticket=" + ticket;
	        System.out.println("Calling URL: " + url);

	        String response = webClient.get()
	                .uri(url)
	                .retrieve()
	                .bodyToMono(String.class)
	                .block();

	        ObjectMapper mapper = new ObjectMapper();
	        JsonNode jsonData = mapper.readTree(response);

	        // Correct extraction
	        JsonNode entries = jsonData.get("list").get("entries");
	        if (entries == null || entries.size() == 0) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                    .body("No containers found for site: " + siteId);
	        }

	        String docLibId = entries.get(0).get("entry").get("id").asText();
	        System.out.println("Document Library Node ID: " + docLibId);

	        // Now fetch children of the document library
	        String childUrl = "http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/nodes/" + docLibId + "/children?alf_ticket=" + ticket;
	        String childResponse = webClient.get()
	                .uri(childUrl)
	                .retrieve()
	                .bodyToMono(String.class)
	                .block();

	        JsonNode finalJsonData = mapper.readTree(childResponse);
	        return ResponseEntity.ok(finalJsonData);

	    } catch (Exception e) {
	        e.printStackTrace();
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                .body("Error fetching site document library: " + e.getMessage());
	    }
	}


	public ResponseEntity<?> getFolderDocuments(String ticket, String folderId) {
		System.out.println("inside the get folder document");
		String url = "http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/nodes/" + folderId + "/children?alf_ticket=" + ticket;
		String response=webClient.get()
				.uri(url)
				.retrieve()
				.bodyToMono(String.class)
				.block();
		System.out.println("response is:"+response);
		
		try {
			ObjectMapper mapper=new ObjectMapper();
			JsonNode jsonData=mapper.readTree(response);
			System.out.println(jsonData);
			return ResponseEntity.ok(jsonData);
		}
		catch(Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("unable to get the folders and files inside a folder");
		}
		
	}

	public String createFolderInAdmin(String ticket, String folderName) {
	    System.out.println("in create folder method");
	    String parentId="9fbb3cdf-e0bb-4188-8741-e29bd247c536";//admin repository node id
	    String url = "http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/nodes/"+parentId+"/children?alf_ticket=" + ticket;

	    Map<String, Object> folderData = new HashMap<>();
	    folderData.put("name", folderName);
	    folderData.put("nodeType", "cm:folder");

	    try {
	        String response = webClient.post()
	                .uri(url)
	                .contentType(MediaType.APPLICATION_JSON)
	                .bodyValue(folderData)
	                .retrieve()
	                .onStatus(HttpStatusCode::isError, clientResponse -> {
	                    return clientResponse.bodyToMono(String.class).flatMap(errorBody -> {
	                        System.err.println("Alfresco error: " + errorBody); // Print full error
	                        return Mono.error(new RuntimeException("Alfresco API error: " + errorBody));
	                    });
	                })
	                .bodyToMono(String.class)
	                .block();

	        System.out.println("Alfresco response: " + response);
	        return response;
	    } catch (Exception e) {
	        System.err.println("Exception occurred while creating folder: " + e.getMessage());
	        e.printStackTrace();
	        return null;
	    }
	}



}
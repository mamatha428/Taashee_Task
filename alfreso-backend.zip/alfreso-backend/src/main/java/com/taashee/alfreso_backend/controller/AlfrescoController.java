package com.taashee.alfreso_backend.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.taashee.alfreso_backend.service.AlfrescoService;

import jakarta.servlet.http.HttpSession;

@RestController
public class AlfrescoController {

	@Autowired
	private AlfrescoService alfrescoService;

	@GetMapping("/test")
	public String testEndpoint() {
		return "Test endpoint is working!";
	}

	@GetMapping("/documents")
	public ResponseEntity<?> getUserDocuments(HttpSession session) {
	    String username = (String) session.getAttribute("username");
	    String ticket = (String) session.getAttribute("ticket");

	    if (username == null || ticket == null) {
	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not logged in");
	    }

	    String userFolderId = alfrescoService.getUserFolderId(username, ticket);

	    if (userFolderId == null) {
	        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User folder not found");
	    }

	    String response = alfrescoService.getUserDocumentsJson(userFolderId, ticket);

	    try {
	        ObjectMapper mapper = new ObjectMapper();
	        JsonNode jsonNode = mapper.readTree(response); // convert String to JSON
	        return ResponseEntity.ok(jsonNode);            //  return as real JSON
	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error parsing JSON");
	    }
	}
	
	
  
	@GetMapping("/all-users")
	public ResponseEntity<?> getAllUsers(HttpSession session) {
	    String ticket = (String) session.getAttribute("ticket");

	    if (ticket == null) {
	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not logged in");
	    }

	    return ResponseEntity.ok(alfrescoService.getAllUsers(ticket));
	}
	@GetMapping("/me")
	public ResponseEntity<String> getLoggedInUsername(HttpSession session) {
	    String username = (String) session.getAttribute("username");
	    if (username == null) {
	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Not logged in");
	    }
	    return ResponseEntity.ok(username);
	}
	@GetMapping("/admin-documents")
	public ResponseEntity<?> getAdminFolders(HttpSession session) {
	    String username = (String) session.getAttribute("username");
	    String ticket = (String) session.getAttribute("ticket");

	    if (username == null || ticket == null) {
	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not logged in");
	    }

	    if (!username.equals("admin")) {
	        return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access denied. Only admin can access this.");
	    }

	    try {
	        String response = alfrescoService.getFoldersUnderRoot(ticket);
	        ObjectMapper mapper = new ObjectMapper();
	        JsonNode json = mapper.readTree(response);

	        return ResponseEntity.ok(json);
	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to fetch admin folders");
	    }
	}

    @GetMapping("/download")
    public ResponseEntity<Resource> download(@RequestParam("nodeId") String nodeId,HttpSession session){
    	String ticket=(String) session.getAttribute("ticket");
    	if(ticket==null) {
    		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    	}
    	return alfrescoService.downloadfilefromAlfresco(nodeId,ticket);
    }
    
    @GetMapping("/group")
    public ResponseEntity<?> listAllGroups(HttpSession session){
    	String ticket=(String) session.getAttribute("ticket");
    	if(ticket==null) {
    		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    	}
    	return alfrescoService.getAllGroups(ticket);
    }
    
    @GetMapping("/sites")
    public ResponseEntity<?> getAllSites(HttpSession session){
    	String ticket=(String) session.getAttribute("ticket");
    	if(ticket==null) {
    		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("admin not logged in");
    	}
    	return alfrescoService.getAllSites(ticket);
    }
    @GetMapping("/sites/{siteId}/documentLibrary")
    public ResponseEntity<?> getSiteDocumentLibrary(@PathVariable String siteId,HttpSession session){
    	String ticket=(String) session.getAttribute("ticket");
    	if(ticket==null) {
    		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("admin not logged in");
    	}
    	return alfrescoService.getSiteDocumentLibrary(siteId,ticket);
    }
    
    @GetMapping("/folders/{folderId}")
    public ResponseEntity<?>  getFolderDocuments(@PathVariable String folderId,HttpSession session){
    	String ticket=(String) session.getAttribute("ticket");
    	if(ticket==null) {
    		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("user not logged in");
    	}
         return alfrescoService.getFolderDocuments(ticket,folderId);
    }
    @PostMapping("/sites")
    public ResponseEntity<?> createSite(@RequestBody Map<String,String> siteData,HttpSession session){
    	String ticket=(String) session.getAttribute("ticket");
    	if(ticket==null) {
    		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("admin not logged in");
    	}
    	return alfrescoService.createSite(ticket,siteData);
    }
    @PostMapping("/upload")
	public ResponseEntity<?> uploadFile(@RequestParam("file") MultipartFile file, HttpSession session) {
	    String ticket = (String) session.getAttribute("ticket");
	    String username = (String) session.getAttribute("username");

	    if (ticket == null || username == null) {
	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not logged in");
	    }

	    String userFolderId = alfrescoService.getUserFolderId(username, ticket);
	    if (userFolderId == null) {
	        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User folder not found");
	    }

	    try {
	        String result = alfrescoService.uploadFileToAlfresco(file, userFolderId, ticket);
	        return ResponseEntity.ok(result);
	    } catch (Exception e) {
	        e.printStackTrace();
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Upload failed: " + e.getMessage());
	    }
	}
	@PostMapping("/admin-upload")
	public ResponseEntity<?> uploadToAnyFolder(
	    @RequestParam("file") MultipartFile file,
	    @RequestParam("folderId") String folderId,
	    HttpSession session
	) {
	    String ticket = (String) session.getAttribute("ticket");
	    String username = (String) session.getAttribute("username");

	    if (ticket == null || username == null || !username.equals("admin")) {
	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Only admin can upload here.");
	    }

	    try {
	        String result = alfrescoService.uploadFileToAlfresco(file, folderId, ticket);
	        return ResponseEntity.ok(result);
	    } catch (Exception e) {
	        e.printStackTrace();
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Upload failed: " + e.getMessage());
	    }
	}

   @PostMapping("/create-group")
   public ResponseEntity<?> createGroup(@RequestBody Map<String,String> groupData,HttpSession session){
	   String ticket=(String) session.getAttribute("ticket");
	   String username=(String) session.getAttribute("username");
	   if(ticket==null || username==null || !username.equals("admin")) {
		   return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Only admin can create groups");
	   }
	   String groupId=groupData.get("id");
	   String displayName=groupData.get("displayName");
	   try {
		   String result=alfrescoService.createGroupInAlfresco(groupId,displayName,ticket);
		   return ResponseEntity.ok(result);
	   }
	   catch(Exception e) {
		   return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create a group "+e.getMessage());
	   }
   }
   
   @PostMapping("/add-user-to-group")
   public ResponseEntity<?>  addUserToGroup(@RequestBody Map<String,String> requestData,HttpSession session){
	   String ticket=(String) session.getAttribute("ticket");
	   String currentUser=(String) session.getAttribute("username");
	   if(ticket==null || currentUser==null ||!currentUser.equals("admin")) {
		   return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Only admin can add user to a group");
	   }
	   String groupId=requestData.get("id");
	   String username=requestData.get("userName");
	   System.out.println("id :"+groupId+" , username:"+username);
	   if(groupId==null || username==null) {
		   return ResponseEntity.badRequest().body("Missing group id or username");
	   }
	   try {
		   String response=alfrescoService.addUsertoGroup(groupId,username,ticket);
		   return ResponseEntity.ok(response);
	   }
	   catch(Exception e) {
		   return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error adding user to a group"+e.getMessage());
	   }
   }
   
   @PostMapping("/create-user")
   public ResponseEntity<?> createUser(@RequestBody Map<String,String> user,HttpSession session){
	   String ticket=(String) session.getAttribute("ticket");
	   if(ticket==null) {
		   return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Admin not logged in");
	   }
	   
	   try {
		   String response=alfrescoService.createUser(user,ticket);
		   return ResponseEntity.ok(response);
	   }
	   catch(Exception e) {
		   return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("User not created");
	   }
   }
   
   
   @PostMapping("/create-folder")
   public ResponseEntity<?> createFolderInAdmin(@RequestBody Map<String,String> requestData,HttpSession session){
	   String ticket=(String) session.getAttribute("ticket");
	   System.out.println("in create folder");
	   if(ticket==null) {
		   return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("admin not logged in");
	   }
	   try {
		   System.out.println("in try");
		   System.out.println("request data:"+requestData);
		   String folderName=requestData.get("folderName");
		   System.out.println(folderName);
		   String response=alfrescoService.createFolderInAdmin(ticket, folderName);
		   System.out.println(response);
		   return ResponseEntity.ok(response);

	   }
	   catch(Exception e) {
		   return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("unable to create a folder in admin repository");
	   }
	  
   }
   @PutMapping("/update-user/{userId}")
   public ResponseEntity<?> updateUser(@PathVariable String userId,@RequestBody Map<String,String> updateData,HttpSession session){
	   String ticket=(String) session.getAttribute("ticket");
	   if(ticket==null) {
		   return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("admin not logged in");
	   }
	   
	   try {
		   String response=alfrescoService.updateUser(updateData,ticket,userId);
		   return ResponseEntity.ok(response);
	   }
	   catch(Exception e) {
		   return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("admin not logged in");
	   }
   }
   
   @PutMapping("/disable-user/{userId}")
   public ResponseEntity<?> disableUser(@PathVariable String userId, HttpSession session) {
       String ticket = (String) session.getAttribute("ticket");
       if (ticket == null) {
           return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Admin not logged in");
       }

       try {
           alfrescoService.disableUser(userId, ticket);
           return ResponseEntity.ok("User disabled successfully");
       } catch (Exception e) {
           e.printStackTrace();
           return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to disable user");
       }
   }

}

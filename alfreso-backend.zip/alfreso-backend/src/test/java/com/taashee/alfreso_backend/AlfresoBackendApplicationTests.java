package com.taashee.alfreso_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlfresoBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}

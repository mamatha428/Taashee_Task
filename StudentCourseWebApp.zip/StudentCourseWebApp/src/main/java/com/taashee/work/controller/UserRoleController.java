package com.taashee.work.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.taashee.work.entity.Role;
import com.taashee.work.entity.User;
import com.taashee.work.repository.RoleRepository;
import com.taashee.work.repository.UserRepository;

@RestController
public class UserRoleController {

	private final UserRepository userRepository;
	private final RoleRepository roleRepository;

	public UserRoleController(UserRepository userRepository, RoleRepository roleRepository) {
		this.userRepository = userRepository;
		this.roleRepository = roleRepository;
	}
	
	@PostMapping(value="/user/add")
	public User saveUserDetails(@RequestBody User user) {
		return userRepository.save(user);
	}
	
	@PostMapping(value="/role/add")
	public Role saveRole(@RequestBody Role role) {
		return roleRepository.save(role);
	}
	
	@GetMapping(value="/user/all")
	public List<User> getAllUsers(){
		return userRepository.findAll();
	}
	
	@GetMapping(value="/role/all")
	public List<Role> getAllRoles(){
		return roleRepository.findAll();
	}
	
	
}

package com.taashee.work.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.taashee.work.entity.Course;
import com.taashee.work.entity.Instructor;
import com.taashee.work.entity.Student;
import com.taashee.work.service.StudentCourseService;

@Controller
@RequestMapping("/instructor")
public class InstructorController {
private final StudentCourseService studentCourseService;
	
	@Autowired
	public InstructorController(StudentCourseService studentCourseService) {
		this.studentCourseService = studentCourseService;
	}
	
    @GetMapping("/dashboard")
    public String adminDashboard(ModelMap modelMap) {
    	List<Student> students=studentCourseService.getAllStudents();
    	List<Course> courses=studentCourseService.getAllCourses();
    	modelMap.put("students", students);
    	modelMap.put("courses", courses);
    	return "instructor-dashboard";
    }
    
    @GetMapping("/addStudentForm")
    public String addInstructorForm(ModelMap modelMap) {
    	modelMap.addAttribute("student",new Student());
    	return "add-student";
    }
   
    
    @PostMapping("/addStudent")
    public String addInstructor(@ModelAttribute Instructor instructor) {
    	studentCourseService.addInstructor(instructor);
    	return "redirect:/instructor/dashboard";
    	
    }
    
    @GetMapping("/assignCourseToStudentForm")
    public String assignCourseForm(ModelMap modelMap) {
    	List<Course> courses=studentCourseService.getAllCourses();
    	List<Student> students=studentCourseService.getAllStudents();
    	modelMap.put("students", students);
    	modelMap.put("courses", courses);
    	return "assign-course-to-student";
    	
    }
    
    @PostMapping(value="/assignCourseToStudent")
    public String addCourse(@RequestParam("courseId") int courseId,@RequestParam("studentId") int studentId) {
    	studentCourseService.assignCourseToStudent(courseId,studentId);
    	return "redirect:/instructor/dashboard";
    }
}
